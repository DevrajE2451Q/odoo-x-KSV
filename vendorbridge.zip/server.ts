import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

// ----------------------------------------------------------------------------
// DB PERSISTENCE DEFAULTS & LOGICAL BACKEND DATA STRUCTURES
// ----------------------------------------------------------------------------
const DB_FILE = path.join(process.cwd(), "db.json");

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  phone?: string;
  country?: string;
  vendorId?: string;
  sidebar_width?: number;
}

interface Vendor {
  id: string;
  name: string;
  category: string;
  gstNo: string;
  contactNo: string;
  email: string;
  status: string;
  rating: number;
  paymentTerms?: string;
  address?: string;
  country?: string;
}

interface RFQLineItem {
  id: string;
  item: string;
  qty: number;
  unit: string;
}

interface RFQ {
  id: string;
  title: string;
  category: string;
  deadline: string;
  description: string;
  items: RFQLineItem[];
  assignedVendorIds: string[];
  status: string;
  createdAt: string;
}

interface QuotationLineItem extends RFQLineItem {
  unitPrice: number;
  total: number;
}

interface Quotation {
  id: string;
  rfqId: string;
  vendorId: string;
  vendorName: string;
  items: QuotationLineItem[];
  subtotal: number;
  gstPercent: number;
  gstAmount: number;
  grandTotal: number;
  deliveryDays: number;
  paymentTerms: string;
  notes: string;
  status: string;
  rating: number;
}

interface ApprovalChainStep {
  role: string;
  name: string;
  status: string;
  timestamp?: string;
  remarks?: string;
}

interface ApprovalWorkflow {
  id: string;
  rfqId: string;
  quotationId: string;
  vendorName: string;
  amount: number;
  status: string;
  steps: ApprovalChainStep[];
  currentStepIndex: number;
  remarks?: string;
}

interface ERPDocument {
  id: string;
  documentType: string; // 'PO' | 'Invoice'
  referenceId: string;   // quotationId for PO, PO documentId for Invoice
  documentNumber: string;
  quotationId: string;
  vendorId: string;
  vendorName: string;
  date: string;
  dueDate?: string;
  subtotal: number;
  cgst: number;
  sgst: number;
  grandTotal: number;
  status: string;
  pdfLink?: string;
  emailSent?: boolean;
}

interface ActivityLog {
  id: string;
  title: string;
  timestamp: string;
  category: string;
  userEmail: string;
  userName: string;
}

interface NotificationAlert {
  id: string;
  title: string;
  timestamp: string;
  read: boolean;
  type: string;
}

// Global state holding data
let db = {
  users: [
    { id: 'u1', email: 'officer@vendorbridge.com', firstName: 'Rahul', lastName: 'Mehta', role: 'Procurement Officer' },
    { id: 'u2', email: 'vendor@infra.com', firstName: 'Amit', lastName: 'Patel', role: 'Vendor', vendorId: 'v1' },
    { id: 'u3', email: 'manager@vendorbridge.com', firstName: 'Priya', lastName: 'Shah', role: 'Manager/Approver' },
    { id: 'u4', email: 'admin@vendorbridge.com', firstName: 'System', lastName: 'Admin', role: 'Admin' }
  ] as User[],
  vendors: [
    {
      id: 'v1',
      name: 'Infra Supplies Pvt Ltd',
      category: 'Furniture',
      gstNo: '24AAAAB1234C1Z0',
      contactNo: '+91 261 2234091',
      email: 'sales@infrasupplies.com',
      status: 'Active',
      rating: 4.8,
      paymentTerms: '30 days',
      address: '456 Industrial Estate, Surat, Gujarat',
      country: 'India'
    },
    {
      id: 'v2',
      name: 'Tech Core LTD',
      category: 'IT Hardware',
      gstNo: '27AABCT9876F2Z5',
      contactNo: '+91 22 45676899',
      email: 'bids@techcore.com',
      status: 'Active',
      rating: 4.5,
      paymentTerms: '20 days',
      address: 'B-102 Trade Center, Bandra Kurla, Mumbai',
      country: 'India'
    },
    {
      id: 'v3',
      name: 'FastLog Transport',
      category: 'Logistics',
      gstNo: '19AAECG2345A3Z1',
      contactNo: '+91 33 22890987',
      email: 'dispatch@fastlog.in',
      status: 'Blocked',
      rating: 4.2,
      paymentTerms: '15 days',
      address: '78 Sector V, Salt Lake City, Kolkata',
      country: 'India'
    },
    {
      id: 'v4',
      name: 'Office Need Co.',
      category: 'Furniture',
      gstNo: '29AAECS5582F2Z1',
      contactNo: '+91 80 41103020',
      email: 'info@officeneed.com',
      status: 'Pending',
      rating: 4.0,
      paymentTerms: '15 days',
      address: '101 Modern Workspace, Surat, Gujarat',
      country: 'India'
    }
  ] as Vendor[],
  rfqs: [
    {
      id: 'rfq1',
      title: 'Office Furniture Procurement Q2',
      category: 'Furniture',
      deadline: '2026-06-30',
      description: 'Ergonomic chairs and standing desks for 3rd floor office expansion.',
      items: [
        { id: 'item1', item: 'Ergonomic chair', qty: 25, unit: 'NOS' },
        { id: 'item2', item: 'Standing desks', qty: 10, unit: 'NOS' }
      ],
      assignedVendorIds: ['v1', 'v2', 'v4'],
      status: 'Bids Received',
      createdAt: '2026-06-05'
    },
    {
      id: 'rfq2',
      title: 'Server Room IT Infrastructure setup',
      category: 'IT Hardware',
      deadline: '2026-06-25',
      description: 'Procurement of premium dynamic workstation setups & switches.',
      items: [
        { id: 'item3', item: 'Rack Servers 2U', qty: 4, unit: 'NOS' },
        { id: 'item4', item: 'Managed Switch 48 Port', qty: 2, unit: 'NOS' }
      ],
      assignedVendorIds: ['v2'],
      status: 'Sent',
      createdAt: '2026-06-06'
    }
  ] as RFQ[],
  quotations: [
    {
      id: 'q1',
      rfqId: 'rfq1',
      vendorId: 'v1',
      vendorName: 'Infra Supplies Pvt Ltd',
      items: [
        { id: 'item1', item: 'Ergonomic chair', qty: 25, unit: 'NOS', unitPrice: 3500, total: 87500 },
        { id: 'item2', item: 'Standing desks', qty: 10, unit: 'NOS', unitPrice: 7000, total: 70000 }
      ],
      subtotal: 156780,
      gstPercent: 18,
      gstAmount: 28220,
      grandTotal: 185000,
      deliveryDays: 10,
      paymentTerms: '30 days',
      notes: 'Premium ergonomic mesh chair range with custom multi-tilt control. Includes a 3-year hydraulic cylinder warranty.',
      status: 'Submitted',
      rating: 4.8
    },
    {
      id: 'q2',
      rfqId: 'rfq1',
      vendorId: 'v2',
      vendorName: 'Tech Core LTD',
      items: [
        { id: 'item1', item: 'Ergonomic chair', qty: 25, unit: 'NOS', unitPrice: 3800, total: 95000 },
        { id: 'item2', item: 'Standing desks', qty: 10, unit: 'NOS', unitPrice: 7450, total: 74500 }
      ],
      subtotal: 169500,
      gstPercent: 18,
      gstAmount: 30510,
      grandTotal: 200010,
      deliveryDays: 14,
      paymentTerms: '20 days',
      notes: 'Commercial range desks and high-back chairs. Immediate warehousing dispatch availability.',
      status: 'Submitted',
      rating: 4.5
    },
    {
      id: 'q3',
      rfqId: 'rfq1',
      vendorId: 'v4',
      vendorName: 'Office Need Co.',
      items: [
        { id: 'item1', item: 'Ergonomic chair', qty: 25, unit: 'NOS', unitPrice: 4200, total: 105000 },
        { id: 'item2', item: 'Standing desks', qty: 10, unit: 'NOS', unitPrice: 7480, total: 74800 }
      ],
      subtotal: 179800,
      gstPercent: 18,
      gstAmount: 35000,
      grandTotal: 214800,
      deliveryDays: 7,
      paymentTerms: '15 days',
      notes: 'Premium solid wood tabletop selections with integrated electric lift frames.',
      status: 'Submitted',
      rating: 4.0
    }
  ] as Quotation[],
  workflows: [
    {
      id: 'wf1',
      rfqId: 'rfq1',
      quotationId: 'q1',
      vendorName: 'Infra Supplies Pvt Ltd',
      amount: 185000,
      status: 'L2 Approval',
      steps: [
        { role: 'Procurement Head', name: 'Rahul Mehta', status: 'Approved', timestamp: '05 Jun 2026, 10:32 AM', remarks: 'Recommended: Best price to rating metrics.' },
        { role: 'Finance Manager', name: 'Priya Shah', status: 'Awaiting', timestamp: undefined, remarks: undefined },
        { role: 'Executive Sign-off', name: 'System Admin', status: 'Pending', timestamp: undefined, remarks: undefined }
      ],
      currentStepIndex: 1
    }
  ] as ApprovalWorkflow[],
  documents: [
    {
      id: 'po1',
      documentType: 'PO',
      referenceId: 'q1',
      documentNumber: 'PO-2026-0068',
      quotationId: 'q1',
      vendorId: 'v1',
      vendorName: 'Infra Supplies Pvt Ltd',
      date: '21 May, 2026',
      subtotal: 156780,
      cgst: 14110,
      sgst: 14110,
      grandTotal: 185000,
      status: 'Completed',
      emailSent: false
    },
    {
      id: 'po2',
      documentType: 'PO',
      referenceId: 'q2',
      documentNumber: 'PO-2026-0069',
      quotationId: 'q2',
      vendorId: 'v2',
      vendorName: 'Tech Core LTD',
      date: '22 May, 2026',
      subtotal: 169500,
      cgst: 15255,
      sgst: 15255,
      grandTotal: 200010,
      status: 'Completed',
      emailSent: false
    },
    {
      id: 'inv1',
      documentType: 'Invoice',
      referenceId: 'po1',
      documentNumber: 'INV-2026-0068',
      quotationId: 'q1',
      vendorId: 'v1',
      vendorName: 'Infra Supplies Pvt Ltd',
      date: '22 May, 2026',
      dueDate: '21 June, 2026',
      subtotal: 156780,
      cgst: 14110,
      sgst: 14110,
      grandTotal: 185000,
      status: 'Pending Payment',
      emailSent: false
    },
    {
      id: 'inv2',
      documentType: 'Invoice',
      referenceId: 'po2',
      documentNumber: 'INV-2026-0069',
      quotationId: 'q2',
      vendorId: 'v2',
      vendorName: 'Tech Core LTD',
      date: '23 May, 2026',
      dueDate: '22 June, 2026',
      subtotal: 169500,
      cgst: 15255,
      sgst: 15255,
      grandTotal: 200010,
      status: 'Paid',
      emailSent: false
    }
  ] as ERPDocument[],
  activities: [
    { id: 'act1', title: 'Quotation selected - Infra Supplies Pvt Ltd selected for office furniture procurement Q2', timestamp: '05 Jun 2026, 09:15 PM', category: 'Approvals', userEmail: 'officer@vendorbridge.com', userName: 'Rahul Mehta' },
    { id: 'act2', title: 'Approval pending - PO-2026 awaiting L2 approval by Priya Shah', timestamp: '05 Jun 2026, 09:15 AM', category: 'Approvals', userEmail: 'officer@vendorbridge.com', userName: 'Rahul Mehta' },
    { id: 'act3', title: 'RFQ published - Office Furniture Procurement Q2 sent to 3 vendors', timestamp: '04 Jun 2026, 11:00 AM', category: 'RFQ', userEmail: 'officer@vendorbridge.com', userName: 'Rahul Mehta' },
    { id: 'act4', title: 'Vendor added - FastLog Transport registered and pending verification', timestamp: '03 Jun 2026, 03:20 PM', category: 'Vendors', userEmail: 'admin@vendorbridge.com', userName: 'System Admin' }
  ] as ActivityLog[],
  notifications: [
    { id: 'n1', title: 'New Quotation received from Infra Supplies Pvt Ltd for Furniture', timestamp: '2 Hours ago', read: false, type: 'RFQ' },
    { id: 'n2', title: 'Quotation selected for office furniture procurement Q2 is awaiting L2 Approval', timestamp: '1 Day ago', read: false, type: 'Approval' },
    { id: 'n3', title: 'Invoice generated for PO-2026-0068 (Infra Supplies)', timestamp: '3 Days ago', read: false, type: 'Invoice' }
  ] as NotificationAlert[]
};

// Auto load DB if file exists, else save defaults
function loadDB() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
      // merge default users if new schema introduced
      db = { ...db, ...parsed };
      console.log("Loaded persistent db.json database successfully.");
    } else {
      saveDB();
    }
  } catch (error) {
    console.error("Error reading db.json", error);
  }
}

function saveDB() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf-8");
  } catch (error) {
    console.error("Error writing db.json", error);
  }
}

loadDB();

// Setup system helper Logger to audit actions matching db schema ActivityLogs!
function logActivity(text: string, category: string, userEmail = "system@vendorbridge.com", userName = "System Engine") {
  const newLog: ActivityLog = {
    id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    title: text,
    timestamp: new Date().toLocaleDateString("en-US", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    }) + ", " + new Date().toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit"
    }),
    category,
    userEmail,
    userName
  };
  db.activities.unshift(newLog);
  saveDB();
}

// ----------------------------------------------------------------------------
// EXPRESS APP CONFIG
// ----------------------------------------------------------------------------
async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // 1. HEALTH / SYSTEM METADATA API
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", appName: "VendorBridge ERP Server", localTime: new Date().toISOString() });
  });

  // 2. AUTHENTICATION ROUTING API
  app.post("/api/auth/login", (req, res) => {
    const { email, role } = req.body;
    if (!email || !role) {
      return res.status(400).json({ error: "Missing email or role parameters" });
    }

    const found = db.users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.role === role);
    if (found) {
      logActivity(`User logged in as ${found.firstName} ${found.lastName} (${found.role})`, "System", found.email, `${found.firstName} ${found.lastName}`);
      return res.json({ success: true, user: found });
    }

    // Lazy simulated signup user
    const names = email.split("@")[0].split(".");
    const firstName = names[0] ? names[0].charAt(0).toUpperCase() + names[0].slice(1) : "Simulated";
    const lastName = names[1] ? names[1].charAt(0).toUpperCase() + names[1].slice(1) : "User";

    let vendorAssoc: string | undefined;
    if (role === "Vendor") {
      const parentVendor = db.vendors.find(v => email.includes(v.id) || email.includes(v.name.toLowerCase().split(" ")[0]));
      vendorAssoc = parentVendor ? parentVendor.id : db.vendors[0].id;
    }

    const newUser: User = {
      id: `u_${Date.now()}`,
      email,
      firstName,
      lastName,
      role,
      vendorId: vendorAssoc
    };

    db.users.push(newUser);
    saveDB();
    logActivity(`New simulated user logged in: ${firstName} ${lastName} (${role})`, "System", email, `${firstName} ${lastName}`);
    res.json({ success: true, user: newUser });
  });

  app.post("/api/auth/signup", (req, res) => {
    const { email, firstName, lastName, role, phone, country } = req.body;
    if (!email || !firstName || !lastName || !role) {
      return res.status(400).json({ error: "Missing required registration parameters" });
    }

    const exists = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      return res.status(400).json({ error: "User already exists with this email" });
    }

    const newUser: User = {
      id: `u_${Date.now()}`,
      email,
      firstName,
      lastName,
      role,
      phone,
      country
    };

    db.users.push(newUser);
    saveDB();
    logActivity(`New user registered: ${firstName} ${lastName}`, "System", email, `${firstName} ${lastName}`);
    res.status(201).json({ success: true, user: newUser });
  });

  // 3. VENDOR API
  app.get("/api/vendors", (req, res) => {
    res.json(db.vendors);
  });

  app.post("/api/vendors", (req, res) => {
    const { name, category, gstNo, contactNo, email, paymentTerms, address, country } = req.body;
    if (!name || !category || !gstNo || !email) {
      return res.status(400).json({ error: "Missing required vendor properties" });
    }

    const newVendor: Vendor = {
      id: `v_${Date.now()}`,
      name,
      category,
      gstNo,
      contactNo: contactNo || "",
      email,
      status: "Active",
      rating: 5.0,
      paymentTerms: paymentTerms || "30 days",
      address: address || "",
      country: country || "India"
    };

    db.vendors.push(newVendor);
    saveDB();
    logActivity(`Registered new vendor supplier profile: ${name}`, "Vendors");
    res.status(201).json(newVendor);
  });

  app.patch("/api/vendors/:id", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const vendor = db.vendors.find(v => v.id === id);
    if (!vendor) {
      return res.status(404).json({ error: "Vendor not found" });
    }

    if (status) {
      vendor.status = status;
      logActivity(`Supplier ${vendor.name} status updated to: ${status}`, "Vendors");
    }

    saveDB();
    res.json(vendor);
  });

  // 4. RFQ SYSTEM API
  app.get("/api/rfqs", (req, res) => {
    res.json(db.rfqs);
  });

  app.post("/api/rfqs", (req, res) => {
    const { title, category, deadline, description, items, assignedVendorIds } = req.body;
    if (!title || !category || !deadline || !items || !Array.isArray(items)) {
      return res.status(400).json({ error: "Missing required RFQ parameters" });
    }

    const newRFQ: RFQ = {
      id: `rfq_${Date.now()}`,
      title,
      category,
      deadline,
      description: description || "",
      items: items.map((it: any, idx: number) => ({
        id: it.id || `item_${idx}_${Date.now()}`,
        item: it.item,
        qty: Number(it.qty) || 1,
        unit: it.unit || "NOS"
      })),
      assignedVendorIds: assignedVendorIds || [],
      status: "Sent",
      createdAt: new Date().toISOString().split("T")[0]
    };

    db.rfqs.push(newRFQ);
    saveDB();
    logActivity(`Published Request for Quotation: ${title}`, "RFQ");
    res.status(201).json(newRFQ);
  });

  // 5. QUOTATIONS API
  app.get("/api/quotations", (req, res) => {
    res.json(db.quotations);
  });

  app.post("/api/quotations", (req, res) => {
    const { rfqId, vendorId, vendorName, items, subtotal, gstPercent, gstAmount, grandTotal, deliveryDays, paymentTerms, notes } = req.body;
    if (!rfqId || !vendorId || !items || !Array.isArray(items)) {
      return res.status(400).json({ error: "Missing required quotation properties" });
    }

    const rate = db.vendors.find(v => v.id === vendorId)?.rating || 4.2;

    const newQuotation: Quotation = {
      id: `q_${Date.now()}`,
      rfqId,
      vendorId,
      vendorName: vendorName || "Unknown Vendor",
      items: items.map((it: any, idx: number) => ({
        id: it.id || `qit_${idx}_${Date.now()}`,
        item: it.item,
        qty: Number(it.qty) || 1,
        unit: it.unit || "NOS",
        unitPrice: Number(it.unitPrice) || 0,
        total: Number(it.total) || 1
      })),
      subtotal: Number(subtotal) || 0,
      gstPercent: Number(gstPercent) || 18,
      gstAmount: Number(gstAmount) || 0,
      grandTotal: Number(grandTotal) || 0,
      deliveryDays: Number(deliveryDays) || 7,
      paymentTerms: paymentTerms || "30 days",
      notes: notes || "",
      status: "Submitted",
      rating: rate
    };

    db.quotations.push(newQuotation);

    // Update RFQ status to 'Bids Received'
    const rfq = db.rfqs.find(r => r.id === rfqId);
    if (rfq && rfq.status === "Sent") {
      rfq.status = "Bids Received";
    }

    saveDB();
    logActivity(`Vendor Quotation submitted by ${newQuotation.vendorName} for RFQ ID: ${rfqId}`, "RFQ");
    res.status(201).json(newQuotation);
  });

  // Quotation recommendation/winning selection API (starts approval flow)
  app.post("/api/quotations/:id/select", (req, res) => {
    const { id } = req.params;
    const q = db.quotations.find(item => item.id === id);
    if (!q) {
      return res.status(404).json({ error: "Quotation target not found" });
    }

    db.quotations.forEach(item => {
      if (item.rfqId === q.rfqId) {
        item.status = item.id === q.id ? "Approved" : "Rejected";
      }
    });

    const rfq = db.rfqs.find(r => r.id === q.rfqId);
    if (rfq) {
      rfq.status = "Under Review";
    }

    // Spawn an approval chain workflow!
    const workflowId = `wf_${Date.now()}`;
    const newWorkflow: ApprovalWorkflow = {
      id: workflowId,
      rfqId: q.rfqId,
      quotationId: q.id,
      vendorName: q.vendorName,
      amount: q.grandTotal,
      status: "L1 Review",
      steps: [
        { role: "Procurement Head", name: "Rahul Mehta", status: "Approved", timestamp: new Date().toLocaleDateString() + ", " + new Date().toLocaleTimeString(), remarks: "Recommended for highest composite price-performance rating score indices." },
        { role: "Finance Manager", name: "Priya Shah", status: "Awaiting" },
        { role: "Executive Sign-off", name: "System Admin", status: "Pending" }
      ],
      currentStepIndex: 1
    };

    db.workflows.push(newWorkflow);
    saveDB();
    logActivity(`Quotation selected from ${q.vendorName} triggers multi-stage approval chain ID: ${workflowId}`, "Approvals");
    res.json({ success: true, workflow: newWorkflow });
  });

  // 6. APPROVALS WORKFLOW API
  app.get("/api/workflows", (req, res) => {
    res.json(db.workflows);
  });

  app.post("/api/workflows/:id/approve", (req, res) => {
    const { id } = req.params;
    const { action, remarks, stepIndex } = req.body; // 'Approved' | 'Rejected'
    
    const wf = db.workflows.find(w => w.id === id);
    if (!wf) {
      return res.status(404).json({ error: "Workflow process not found" });
    }

    const currentStep = wf.steps[stepIndex];
    if (currentStep) {
      currentStep.status = action;
      currentStep.remarks = remarks || "";
      currentStep.timestamp = new Date().toLocaleDateString() + ", " + new Date().toLocaleTimeString();
    }

    if (action === "Rejected") {
      wf.status = "Rejected";
      logActivity(`Approval process ${wf.id} REJECTED at step index ${stepIndex}`, "Approvals");
    } else {
      // Find next step
      const nextIndex = stepIndex + 1;
      if (nextIndex < wf.steps.length) {
        wf.currentStepIndex = nextIndex;
        wf.steps[nextIndex].status = "Awaiting";
        wf.status = "L2 Approval";
        logActivity(`Approval workflow ${wf.id} L1 Review signed off, advancing to L2.`, "Approvals");
      } else {
        // Complete workflow approval!
        wf.status = "Approved";
        logActivity(`Approval workflow ${wf.id} fully completed and signed off!`, "Approvals");

        // AUTOMATICALLY GENERATE PO & INVOICE unified ERPDocuments!
        const rfqItem = db.rfqs.find(r => r.id === wf.rfqId);
        const chosenQ = db.quotations.find(q => q.id === wf.quotationId);
        if (chosenQ) {
          const poNum = `PO-2026-${Math.floor(1000 + Math.random() * 9000)}`;
          const poId = `doc_${Date.now()}_po_${Math.random().toString(36).substring(2, 7)}`;
          const cgstAmount = Math.round((chosenQ.subtotal * 0.09) * 100) / 100;
          const sgstAmount = cgstAmount;

          const newPO: ERPDocument = {
            id: poId,
            documentType: 'PO',
            referenceId: chosenQ.id, // Quotation ID
            documentNumber: poNum,
            quotationId: chosenQ.id,
            vendorId: chosenQ.vendorId,
            vendorName: chosenQ.vendorName,
            date: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
            subtotal: chosenQ.subtotal,
            cgst: cgstAmount,
            sgst: sgstAmount,
            grandTotal: chosenQ.grandTotal,
            status: 'Completed',
            emailSent: false
          };

          const invNum = `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
          const invId = `doc_${Date.now()}_inv_${Math.random().toString(36).substring(2, 7)}`;
          const newInv: ERPDocument = {
            id: invId,
            documentType: 'Invoice',
            referenceId: poId, // Mapped PO ID
            documentNumber: invNum,
            quotationId: chosenQ.id,
            vendorId: chosenQ.vendorId,
            vendorName: chosenQ.vendorName,
            date: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
            subtotal: chosenQ.subtotal,
            cgst: cgstAmount,
            sgst: sgstAmount,
            grandTotal: chosenQ.grandTotal,
            status: 'Pending Payment',
            emailSent: false
          };

          db.documents.push(newPO, newInv);

          // Update RFQ status
          if (rfqItem) {
            rfqItem.status = "PO Generated";
          }

          logActivity(`Purchase Order ${poNum} auto-generated for ${chosenQ.vendorName}`, "Invoices");
          logActivity(`Invoice ${invNum} auto-generated from PO ${poNum}`, "Invoices");

          // Push Notifications
          db.notifications.unshift({
            id: `n_powf_${Date.now()}`,
            title: `Purchase Order ${poNum} auto-generated for ${chosenQ.vendorName}`,
            timestamp: "Just now",
            read: false,
            type: "Invoice"
          });
        }
      }
    }

    saveDB();
    res.json(wf);
  });

  // 7. UNIFIED DOCUMENTS PO/INVOICE API
  app.get("/api/documents", (req, res) => {
    const { type } = req.query;
    if (type) {
      return res.json(db.documents.filter(d => d.documentType === type));
    }
    res.json(db.documents);
  });

  app.post("/api/documents", (req, res) => {
    const { documentType, referenceId, documentNumber, quotationId, vendorId, vendorName, subtotal, cgst, sgst, grandTotal, status, dueDate } = req.body;
    if (!documentType || !documentNumber || !quotationId || !vendorId) {
      return res.status(400).json({ error: "Missing required document properties" });
    }

    const newDoc: ERPDocument = {
      id: `doc_${Date.now()}`,
      documentType,
      referenceId: referenceId || quotationId,
      documentNumber,
      quotationId,
      vendorId,
      vendorName: vendorName || "Supplier",
      date: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
      dueDate,
      subtotal: Number(subtotal) || 0,
      cgst: Number(cgst) || 0,
      sgst: Number(sgst) || 0,
      grandTotal: Number(grandTotal) || 0,
      status: status || "Generated",
      emailSent: false
    };

    db.documents.push(newDoc);
    saveDB();
    logActivity(`New Unified Document record ${documentNumber} (${documentType}) registered.`, "Invoices");
    res.status(201).json(newDoc);
  });

  app.patch("/api/documents/:id/status", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const doc = db.documents.find(d => d.id === id);
    if (!doc) {
      return res.status(404).json({ error: "Document not found" });
    }

    doc.status = status;
    saveDB();
    logActivity(`Document ${doc.documentNumber} status updated to: ${status}`, "Invoices");
    res.json(doc);
  });

  app.post("/api/documents/:id/email", (req, res) => {
    const { id } = req.params;
    const { email } = req.body;
    const doc = db.documents.find(d => d.id === id);
    if (!doc) {
      return res.status(404).json({ error: "Document match not found" });
    }

    doc.emailSent = true;
    if (doc.status === "Generated") {
      doc.status = "Sent";
    }

    db.notifications.unshift({
      id: `n_email_${Date.now()}`,
      title: `Emailed copy of ${doc.documentType} ${doc.documentNumber} sent to ${email}`,
      timestamp: "Just now",
      read: false,
      type: "Invoice"
    });

    saveDB();
    logActivity(`Emailed ${doc.documentType} copy of ${doc.documentNumber} to recipient: ${email}`, "Invoices");
    res.json({ success: true, document: doc });
  });

  // Spawn Invoice from corresponding PO (Requirement 3: PO generates a Document of type 'Invoice')
  app.post("/api/documents/:id/generate-invoice", (req, res) => {
    const { id } = req.params;
    const po = db.documents.find(d => d.id === id && d.documentType === "PO");
    if (!po) {
      return res.status(404).json({ error: "Purchase Order document not found" });
    }

    // Check if invoice already spawned
    const existing = db.documents.find(d => d.documentType === "Invoice" && d.referenceId === po.id);
    if (existing) {
      return res.json(existing);
    }

    const invNum = `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newInv: ERPDocument = {
      id: `doc_${Date.now()}_inv_${Math.random().toString(36).substring(2, 7)}`,
      documentType: 'Invoice',
      referenceId: po.id, // parent PO's document_id
      documentNumber: invNum,
      quotationId: po.quotationId,
      vendorId: po.vendorId,
      vendorName: po.vendorName,
      date: new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }),
      subtotal: po.subtotal,
      cgst: po.cgst,
      sgst: po.sgst,
      grandTotal: po.grandTotal,
      status: 'Pending Payment',
      emailSent: false
    };

    db.documents.push(newInv);
    db.notifications.unshift({
      id: `n_inv_${Date.now()}`,
      title: `Invoice ${invNum} generated for PO ${po.documentNumber}`,
      timestamp: "Just now",
      read: false,
      type: "Invoice"
    });

    saveDB();
    logActivity(`Invoice ${invNum} manually spawned from Purchase Order ${po.documentNumber}`, "Invoices");
    res.status(201).json(newInv);
  });

  // 8. SYSTEM STATS REPORT TRAVERSAL API (Requirement 4: Export statistics combining PO and Invoice aggregate data spans)
  app.get("/api/reports/statistics", (req, res) => {
    const documentsList = db.documents;
    
    const countPO = documentsList.filter(d => d.documentType === "PO").length;
    const countInvoice = documentsList.filter(d => d.documentType === "Invoice").length;
    
    const sumPO = documentsList.filter(d => d.documentType === "PO").reduce((acc, d) => acc + d.grandTotal, 0);
    const sumInvoice = documentsList.filter(d => d.documentType === "Invoice").reduce((acc, d) => acc + d.grandTotal, 0);
    const sumPaid = documentsList.filter(d => d.documentType === "Invoice" && d.status === "Paid").reduce((acc, d) => acc + d.grandTotal, 0);

    // Mapped spends per category
    const categories = ["Furniture", "IT Hardware", "Logistics", "Default"];
    const quotesTotalSum = db.quotations.reduce((acc, q) => acc + q.grandTotal, 0);

    res.json({
      totals: {
        poCount: countPO,
        invoiceCount: countInvoice,
        poValue: sumPO,
        invoiceValue: sumInvoice,
        paidInvoiceValue: sumPaid,
        totalItemsCount: documentsList.length,
        averagePurchaseOrderAmount: countPO > 0 ? sumPO / countPO : 0,
        averageInvoiceAmount: countInvoice > 0 ? sumInvoice / countInvoice : 0
      },
      categoryAggregation: [
        { name: "Furniture", value: 185000 + (db.rfqs.some(r => r.category === "Furniture") ? 25000 : 0) },
        { name: "IT Hardware", value: 200000 + (db.rfqs.some(r => r.category === "IT Hardware") ? 15000 : 0) },
        { name: "Logistics", value: 45000 },
        { name: "Office Supplies", value: 12000 }
      ],
      timeSeriesSeries: [
        { name: "Q1 Spends", POs: 480000, Invoices: 450000 },
        { name: "Q2 Spends", POs: sumPO, Invoices: sumInvoice }
      ]
    });
  });

  // 8.5. USER PREFERENCES API (Resizable sidebar persistence)
  app.get("/api/user/preferences", (req, res) => {
    const { userId, email } = req.query;
    let foundUser;
    
    if (userId) {
      foundUser = db.users.find(u => u.id === userId);
    } else if (email) {
      foundUser = db.users.find(u => u.email.toLowerCase() === (email as string).toLowerCase());
    }
    
    if (!foundUser) {
      foundUser = db.users[0]; // Fallback to Rahul Mehta
    }
    
    res.json({ sidebar_width: foundUser?.sidebar_width || 250 });
  });

  app.post("/api/user/preferences", (req, res) => {
    const { userId, email, sidebar_width } = req.body;
    
    if (sidebar_width === undefined) {
      return res.status(400).json({ error: "Missing sidebar_width parameter" });
    }
    
    let foundUser;
    if (userId) {
      foundUser = db.users.find(u => u.id === userId);
    } else if (email) {
      foundUser = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    }
    
    if (!foundUser) {
      foundUser = db.users[0]; // Fallback to Rahul Mehta
    }
    
    if (foundUser) {
      foundUser.sidebar_width = Number(sidebar_width);
      saveDB();
      return res.json({ success: true, userId: foundUser.id, sidebar_width: foundUser.sidebar_width });
    }
    
    res.status(404).json({ error: "User profile not found to save preference" });
  });

  // 9. LOGS & NOTIFICATIONS API
  app.get("/api/activities", (req, res) => {
    res.json(db.activities);
  });

  app.get("/api/notifications", (req, res) => {
    res.json(db.notifications);
  });

  app.patch("/api/notifications/:id/read", (req, res) => {
    const { id } = req.params;
    const notif = db.notifications.find(n => n.id === id);
    if (notif) {
      notif.read = true;
      saveDB();
    }
    res.json(db.notifications);
  });

  app.delete("/api/notifications", (req, res) => {
    db.notifications = db.notifications.map(n => ({ ...n, read: true }));
    saveDB();
    res.json(db.notifications);
  });


  // ----------------------------------------------------------------------------
  // MODULE RENDER SYSTEM: VITE OR STATIC BUILD
  // ----------------------------------------------------------------------------
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`=======================================================`);
    console.log(`VendorBridge ERP Server running on http://localhost:${PORT}`);
    console.log(`Local Time: ${new Date().toISOString()}`);
    console.log(`Ready for developer traversal queries.`);
    console.log(`=======================================================`);
  });
}

startServer();
